/* map.js - Mapa interactivo con Leaflet para ForaneosHub
   Requisitos: incluir Leaflet CSS y JS antes de este archivo.

   API rápida:
   MapModule.render(containerId, options)
   options: {
     listingImg?: string,             // para inferir coords por demo (casa1.jpg, etc.)
     listingCoords?: [number,number], // si ya tienes coords, mándalas
     zoneLabel?: string,              // "Zona Centro", "Cerca de UPT", etc. para riesgo
     risk?: 'green'|'yellow'|'red',   // opcional: sobreescribe el color de riesgo
   }
*/
(function(global){
  const L_READY = typeof L !== 'undefined';
  const UPT = { name: 'Universidad Politécnica de Tulancingo', coords: [20.1273, -98.3792] }; // Ajusta si es necesario

  // Tabla demo: imagen -> coordenadas (sin geocoding)
  const DEMO_LISTING_BY_IMG = {
    'casa1.jpg': { title:'Casa popular', coords:[20.0820,-98.3600] },
    'casa2.jpg': { title:'Habitación',   coords:[20.0860,-98.3660] },
    'casa3.jpg': { title:'Loft',         coords:[20.0798,-98.3746] },
    'habitacion.jpg': { title:'Depto',   coords:[20.0859,-98.3734] },
  };

  // Puntos de interés (demo)
  const POIS = [
    { name: 'Parque La Floresta', coords: [20.080633657471868, -98.36893846895114], color: 'green' },
    { name: 'Mercado municipal',  coords: [20.081822751133064, -98.36661380560375], color: 'green' },
    { name: 'Base de combis',     coords: [20.08432935868926,  -98.36722992817757], color: 'green' },
  ];

  // Rutas de transporte (demo) hacia/desde UPT
  const RUTA_LLEGADA = [
    [20.084342157233436, -98.36727762352126],
    [20.07940742454196,  -98.36852313445962],
    [20.079816943823886, -98.37458558294601],
    [20.085927754630923, -98.3734682970412],
    [20.08611947931158,  -98.37277772655649],
    [20.08649295832856,  -98.37220795055727],
    [20.08694322989381,  -98.37195853951951],
    [20.121664148543925, -98.36547863985214],
    [20.123119252853016, -98.37035132968684],
    [20.12269614849901,  -98.3751149328082],
    [20.128416185498846, -98.3807367485599],
    [20.133961722744164, -98.3797450677972],
  ];
  // Regreso: misma ruta (puedes ajustar si difiere)
  const RUTA_REGRESO = RUTA_LLEGADA.slice().reverse();

  // Riesgo por zona (demo)
  function inferRiskByZone(label){
    const s = (label||'').toLowerCase();
    if(s.includes('centro')) return 'yellow';
    if(s.includes('upt')) return 'green';
    return 'green';
  }
  function getSavedRisk(label){
    try{
      const key = 'risk:zone:' + (label||'').toLowerCase();
      const v = localStorage.getItem(key);
      if(v && (v==='green' || v==='yellow' || v==='red')) return v;
    }catch(_){ }
    return null;
  }
  function setZoneRisk(label, risk){
    try{
      const v = (risk||'').toLowerCase();
      if(['green','yellow','red'].includes(v)) localStorage.setItem('risk:zone:'+(label||'').toLowerCase(), v);
    }catch(_){ }
  }

  // Utilidades
  function kmBetween(a,b){
    const R=6371; const [lat1,lon1]=a, [lat2,lon2]=b;
    const dLat=(lat2-lat1)*Math.PI/180, dLon=(lon2-lon1)*Math.PI/180;
    const x=Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLon/2)**2;
    return 2*R*Math.asin(Math.sqrt(x));
  }
  function estimateTimeCost_km(km){
    // Suposición: 25 km/h promedio; costo fijo $10 por trayecto
    const mins = Math.round((km/25)*60);
    const costOneWay = 10;
    const costRound = 20;
    return { mins, costOneWay, costRound };
  }
  function estimateWalkMins_km(km){
    // 4.8 km/h caminando (aprox 12.5 min por km)
    return Math.max(1, Math.round((km/4.8)*60));
  }

  const instances = new Map(); // containerId -> map
  const multiState = new Map(); // containerId -> { group, markers: Map<id,{marker,connector}> }

  function ensureMap(containerId, center){
    const el = document.getElementById(containerId);
    if(!el) return null;
    // Si ya existe, reset
    if(instances.has(containerId)){
      try{ instances.get(containerId).remove(); }catch(_){ }
      instances.delete(containerId);
    }
    const map = L.map(containerId, { zoomControl: true }).setView(center||UPT.coords, 14);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors'
    }).addTo(map);
    instances.set(containerId, map);
    setTimeout(()=> map.invalidateSize(), 50);
    return map;
  }

  function tintZone(map, center, risk){
    const color = risk==='red'?'#ef4444': risk==='yellow'?'#f59e0b':'#22c55e';
    L.circle(center, { radius: 600, color, fillColor: color, fillOpacity: .18, weight: 2 }).addTo(map)
      .bindTooltip(risk==='red'?'Zona: Riesgo alto': risk==='yellow'?'Zona: Riesgo moderado':'Zona: Segura', {permanent:false});
  }

  function addUPT(map){
    L.marker(UPT.coords, { title: UPT.name }).addTo(map).bindPopup(`<b>${UPT.name}</b>`);
  }
  function addRoutes(map){
    L.polyline(RUTA_LLEGADA, { color:'#dc2626', weight:4, opacity:.9 }).addTo(map).bindTooltip('Ruta de llegada a UPT');
    L.polyline(RUTA_REGRESO, { color:'#2563eb', weight:4, opacity:.9 }).addTo(map).bindTooltip('Ruta de regreso de UPT');
  }

  // Control de leyenda con SVG (Rojo: ida, Azul: regreso)
  function addLegend(map){
    const Legend = L.Control.extend({
      options: { position: 'bottomleft' },
      onAdd: function(){
        const container = L.DomUtil.create('div', 'leaflet-control');
        container.style.background = 'var(--card)';
        container.style.color = 'var(--text)';
        container.style.border = '1px solid var(--border)';
        container.style.borderRadius = '10px';
        container.style.boxShadow = '0 6px 20px rgba(0,0,0,.15)';
        container.style.padding = '8px 10px';
        container.style.fontSize = '12px';
        container.style.display = 'flex';
        container.style.alignItems = 'center';
        container.style.gap = '10px';
        container.setAttribute('aria-label','Leyenda de rutas');
        container.innerHTML = `
          <svg width="160" height="28" viewBox="0 0 160 28" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Leyenda de rutas">
            <g>
              <line x1="8" y1="8" x2="58" y2="8" stroke="#dc2626" stroke-width="4" stroke-linecap="round"/>
              <text x="64" y="11" fill="currentColor" font-size="12" dominant-baseline="middle">Ida</text>
            </g>
            <g>
              <line x1="8" y1="20" x2="58" y2="20" stroke="#2563eb" stroke-width="4" stroke-linecap="round"/>
              <text x="64" y="21" fill="currentColor" font-size="12" dominant-baseline="middle">Regreso</text>
            </g>
          </svg>`;
        // Evita que el arrastre/click del control afecte al mapa
        L.DomEvent.disableClickPropagation(container);
        L.DomEvent.disableScrollPropagation(container);
        return container;
      }
    });
    map.addControl(new Legend());
  }
  function addPOIs(map){
    for(const p of POIS){
      L.circleMarker(p.coords, { radius:7, color:p.color||'green', fillColor:p.color||'green', fillOpacity:.8 })
        .addTo(map).bindPopup(`<b>${p.name}</b>`);
    }
  }
  function getTransportPOI(){
    return POIS.find(p => (p.name||'').toLowerCase().includes('base')) || POIS[0];
  }

  function resolveListing(options){
    if(options.listingCoords) return { coords: options.listingCoords, title: 'Alojamiento' };
    const src = options.listingImg||'';
    const key = Object.keys(DEMO_LISTING_BY_IMG).find(k => src.endsWith(k)) || '';
    return key ? DEMO_LISTING_BY_IMG[key] : null;
  }

  function render(containerId, options){
    if(!L_READY) return;
  const zoneRisk = options.risk || getSavedRisk(options.zoneLabel||'') || inferRiskByZone(options.zoneLabel||'');
    const listing = resolveListing(options) || { coords:[20.0833,-98.3667], title:'Alojamiento' };

    const map = ensureMap(containerId, listing.coords);
    if(!map) return;

    // Riesgo de zona
    tintZone(map, listing.coords, zoneRisk);
    // UPT
    addUPT(map);
    // Rutas
    addRoutes(map);
    // POIs
    addPOIs(map);
  // Leyenda SVG
  addLegend(map);

    // Marcador vivienda con tiempo y costo
    const km = kmBetween(listing.coords, UPT.coords);
    const est = estimateTimeCost_km(km);
    const marker = L.marker(listing.coords, { title: listing.title }).addTo(map)
      .bindPopup(`<b>${listing.title}</b><br>Distancia a UPT: ${km.toFixed(2)} km<br>Tiempo aprox.: ${est.mins} min<br>Costo estimado: $${est.costOneWay} MXN (ida) · $${est.costOneWay} MXN (regreso) · Total $${est.costRound}`);
    if(options.showPopup !== false){ try{ marker.openPopup(); }catch(_){ } }
    if(typeof options.onComputed === 'function'){
      try{
        options.onComputed({ km: Number(km.toFixed(2)), mins: est.mins, costOneWay: est.costOneWay, costRound: est.costRound });
      }catch(_){ }
    }

    // Ajuste de vista: que quepa vivienda y UPT
    const bounds = L.latLngBounds([ listing.coords, UPT.coords ]);
    try{ map.fitBounds(bounds.pad(0.25)); }catch(_){ }
    setTimeout(()=> map.invalidateSize(), 120);
  }

  // --- API para vista múltiple ---
  function initMulti(containerId, opts){
    if(!L_READY) return null;
    const map = ensureMap(containerId, UPT.coords);
    if(!map) return null;
    // base
    addUPT(map);
    addRoutes(map);
    addPOIs(map);
    addLegend(map);
    // group para listings y conectores
    const group = L.layerGroup().addTo(map);
    multiState.set(containerId, { group, markers: new Map(), map });
    // enfoque inicial
    try{ map.setView(UPT.coords, 13); }catch(_){ }
    return map;
  }
  function clearListings(containerId){
    const st = multiState.get(containerId);
    if(!st) return;
    st.group.clearLayers();
    st.markers.clear();
  }
  function addListingTo(containerId, opts){
    const st = multiState.get(containerId);
    if(!st) return null;
    const { group } = st;
    const title = opts.title || 'Alojamiento';
    const coords = opts.coords || UPT.coords;
    const km = kmBetween(coords, UPT.coords);
    const est = estimateTimeCost_km(km);
    const m = L.marker(coords, { title }).addTo(group)
      .bindPopup(`<b>${title}</b><br>Distancia a UPT: ${km.toFixed(2)} km<br>Tiempo aprox.: ${est.mins} min<br>Costo transporte: $${est.costOneWay} (ida) + $${est.costOneWay} (regreso) = $${est.costRound}`);
    // conector a transporte (camino)
    const poi = getTransportPOI();
    let connector = null;
    if(poi){
      connector = L.polyline([coords, poi.coords], { color:'#f59e0b', weight:3, opacity:.9, dashArray:'6,6' })
        .addTo(group).bindTooltip('Caminar al transporte');
    }
    const id = opts.id || ('mk-'+Math.random().toString(36).slice(2));
    st.markers.set(id, { marker:m, connector });
    // callback con métricas
    if(typeof opts.onComputed === 'function'){
      try{
        const walkKm = poi ? kmBetween(coords, poi.coords) : 0;
        const walkMins = poi ? estimateWalkMins_km(walkKm) : 0;
        opts.onComputed({ id, km: Number(km.toFixed(2)), mins: est.mins, costOneWay: est.costOneWay, costRound: est.costRound, walkKm: Number(walkKm.toFixed(2)), walkMins });
      }catch(_){ }
    }
    return { id, marker:m, connector };
  }
  function fitToAll(containerId){
    const st = multiState.get(containerId);
    const map = instances.get(containerId);
    if(!st || !map) return;
    const layers = [];
    st.group.eachLayer(l=> layers.push(l));
    // incluir UPT
    layers.push(L.marker(UPT.coords));
    if(layers.length){
      const bounds = L.latLngBounds([]);
      layers.forEach(l=>{
        try{
          if(l.getLatLng) bounds.extend(l.getLatLng());
          else if(l.getBounds) bounds.extend(l.getBounds());
        }catch(_){ }
      });
      try{ map.fitBounds(bounds.pad(0.25)); }catch(_){ }
      setTimeout(()=> map.invalidateSize(), 120);
    }
  }
  function openListing(containerId, id){
    const st = multiState.get(containerId);
    const map = instances.get(containerId);
    if(!st || !map) return false;
    const rec = st.markers.get(id);
    if(!rec) return false;
    try{
      const ll = rec.marker.getLatLng();
      map.setView(ll, Math.max(15, map.getZoom()||15), { animate:true });
      rec.marker.openPopup();
      return true;
    }catch(_){ return false; }
  }

  global.MapModule = {
    render,
    setZoneRisk,
    // múltiple
    initMulti,
    addListingTo,
    clearListings,
    fitToAll,
  openListing,
    // utils
    utils: {
      kmBetween,
      estimateTimeCost_km,
      estimateWalkMins_km,
      UPT,
      getTransportPOI
    }
  };
})(window);
