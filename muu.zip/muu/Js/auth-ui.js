// auth-ui.js
// Gestiona el estado de sesión para la UI usando una bandera inyectada por el servidor
// y provee fallback a localStorage durante desarrollo.

(function () {
  // Detecta si hay sesión iniciada: preferir bandera del servidor, si no usar localStorage
  function isLoggedIn() {
    if (typeof window.IS_LOGGED_IN === 'boolean') {
      return window.IS_LOGGED_IN;
    }
    try {
      return localStorage.getItem('isLoggedIn') === 'true';
    } catch (_) {
      return false;
    }
  }

  // Exponer utilidades
  window.AuthUI = {
    isLoggedIn,
    setLoggedIn: function (value) {
      try { localStorage.setItem('isLoggedIn', value ? 'true' : 'false'); } catch (_) {}
    },
    logout: function () {
      try { localStorage.removeItem('isLoggedIn'); } catch (_) {}
      // Si el servidor expone una ruta de logout, puedes llamarla aquí.
      // fetch('/logout', { method: 'POST', credentials: 'include' }).catch(() => {});
    }
  };

  // Inicializa comportamiento común para headers: mostrar/ocultar login/logout
  document.addEventListener('DOMContentLoaded', function () {
    const loginLink = document.querySelector('.header-links a[href="Login.html"]');
    const logoutLink = document.getElementById('logout-link');
    const logged = isLoggedIn();
    if (logoutLink) {
      if (logged) {
        logoutLink.style.display = 'inline';
        if (loginLink) loginLink.style.display = 'none';
      } else {
        logoutLink.style.display = 'none';
        if (loginLink) loginLink.style.display = 'inline';
      }
      logoutLink.addEventListener('click', function (e) {
        e.preventDefault();
        window.AuthUI.logout();
        if (loginLink) loginLink.style.display = 'inline';
        logoutLink.style.display = 'none';
      });
    }

    // Publicar Alojamiento: si no hay sesión, ir a datos del arrendador; si hay, ir a Registro de Alojamiento
    const publicarLink = document.querySelector('.header-links a[href="Registro de Alojamiento.html"]');
    if (publicarLink) {
      if (!isLoggedIn()) {
        publicarLink.title = 'Completa tus datos como arrendador para publicar';
      }
      publicarLink.addEventListener('click', function (e) {
        if (!isLoggedIn()) {
          e.preventDefault();
          location.href = 'datos_arrendador.HTML';
        }
      });
    }

    // Botón de "Buscar alojamiento ahora": ir a búsqueda si hay sesión, o a perfiles si no.
    const buscarBtn = document.querySelector('.hero-btn');
    if (buscarBtn) {
      buscarBtn.addEventListener('click', function () {
        if (isLoggedIn()) {
          location.href = 'Interfaz_de_Busqueda_Avanzada.html';
        } else {
          const seccion = document.getElementById('perfiles');
          if (seccion && seccion.scrollIntoView) {
            seccion.scrollIntoView({ behavior: 'smooth', block: 'start' });
            try {
              seccion.classList.add('highlight-pulse');
              setTimeout(() => seccion.classList.remove('highlight-pulse'), 1300);
            } catch (_) {}
          } else {
            location.hash = '#perfiles';
          }
        }
      });
    }

    // Botón "Regístrate Gratis": llevar siempre a la sección de perfiles
    const registrateBtn = document.querySelector('.registro-btn');
    if (registrateBtn) {
      // Deshabilitar si hay sesión
      if (isLoggedIn()) {
        registrateBtn.disabled = true;
        registrateBtn.setAttribute('aria-disabled', 'true');
        registrateBtn.title = 'Ya tienes una sesión activa';
      }
      registrateBtn.addEventListener('click', function (e) {
        if (registrateBtn.disabled) { e.preventDefault(); return; }
        const seccion = document.getElementById('perfiles');
        if (seccion && seccion.scrollIntoView) {
          seccion.scrollIntoView({ behavior: 'smooth', block: 'start' });
          try {
            seccion.classList.add('highlight-pulse');
            setTimeout(() => seccion.classList.remove('highlight-pulse'), 1300);
          } catch (_) {}
        } else {
          location.hash = '#perfiles';
        }
      });
    }

    // Deshabilitar "Soy arrendador" / "Soy arrendatario" si ya hay sesión
    try{
      const perfilBtns = Array.from(document.querySelectorAll('button.perfil-btn'));
      const targets = perfilBtns.filter(btn => /Soy\s+arrendador|Soy\s+arrendatario/i.test(btn.textContent||''));
      const loggedNow = isLoggedIn();
      for(const btn of targets){
        if (loggedNow) {
          btn.disabled = true;
          btn.setAttribute('aria-disabled', 'true');
          btn.title = 'Ya tienes una sesión activa';
          // Evitar cualquier navegación inline
          try{ btn.onclick = null; btn.removeAttribute('onclick'); }catch(_){}
        } else {
          btn.disabled = false;
          btn.removeAttribute('aria-disabled');
          if (btn.title === 'Ya tienes una sesión activa') btn.removeAttribute('title');
        }
      }
    }catch(_){ }
  });
})();
