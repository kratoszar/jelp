(function(){
  const STORAGE_KEY = 'theme';
  const root = document.documentElement;

  function updateControls(theme){
    // Sincroniza todos los switches: aria-pressed y etiqueta
    const pressed = String(theme === 'dark');
    document.querySelectorAll('#themeToggle, .theme-toggle').forEach(btn => {
      try{ btn.setAttribute('aria-pressed', pressed); }catch(_){}
      const label = btn.querySelector('.theme-label');
      if(label){ label.textContent = theme === 'dark' ? 'Modo claro' : 'Modo oscuro'; }
    });
  }

  function apply(theme){
    root.setAttribute('data-theme', theme);
    if (theme === 'dark') root.classList.add('dark'); else root.classList.remove('dark');
    try{ root.style.colorScheme = theme === 'dark' ? 'dark' : 'light'; }catch(_){ }
    updateControls(theme);
  }

  function get(){
    try{
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return saved;
    }catch(_){ }
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }

  function toggle(){
    const curr = root.getAttribute('data-theme') || 'light';
    const next = curr === 'dark' ? 'light' : 'dark';
    apply(next);
    try{ localStorage.setItem(STORAGE_KEY, next); }catch(_){ }
  }

  // init
  const initial = get();
  apply(initial);

  // Inicializa controles al cargar DOM (por si se inyectan tarde)
  document.addEventListener('DOMContentLoaded', function(){ updateControls(get()); });

  // Click delegado para cualquier botón con id #themeToggle o clase .theme-toggle
  // Evita doble toggle si otra lógica ya manejó el clic (defaultPrevented)
  document.addEventListener('click', (e)=>{
    if (e.defaultPrevented) return;
    const btn = e.target.closest && e.target.closest('#themeToggle, .theme-toggle');
    if (btn) {
      e.preventDefault();
      toggle();
    }
  });

  // expose
  window.Theme = { toggle, apply, get };
})();
