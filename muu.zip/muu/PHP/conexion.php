<?php
$servidor = "localhost";
$usuario = "root";
$clave = "";
$bd = "foraneoshub"; 
$conn = new mysqli($servidor, $usuario, $clave, $bd);
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
?>
