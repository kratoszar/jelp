<?php
require "conexion.php";

// Recibir datos del formulario
$nombre = $_POST['nombre'] ?? '';
$email = $_POST['email'] ?? '';
$fecha_nacimiento = $_POST['fecha_nacimiento'] ?? '';
$universidad = $_POST['universidad'] ?? '';
$telefono = $_POST['telefono'] ?? '';
$password = $_POST['password'] ?? '';
$confirmar = $_POST['confirmar'] ?? '';

// Validar contraseñas
if ($password !== $confirmar) {
    die("Las contraseñas no coinciden.");
}

// Encriptar contraseña
$passHash = password_hash($password, PASSWORD_DEFAULT);

// Insertar en la base de datos
$sql = "INSERT INTO arrendatarios (nombre, email, fecha_nacimiento, universidad, telefono, password) 
        VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssss", $nombre, $email, $fecha_nacimiento, $universidad, $telefono, $passHash);

if ($stmt->execute()) {
    echo "Arrendatario registrado con éxito.";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
