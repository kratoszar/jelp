<?php
include 'conexion.php';

// Recibir datos
$nombre = $_POST['nombre'] ?? '';
$email = $_POST['email'] ?? '';
$fecha_nacimiento = $_POST['fecha_nacimiento'] ?? '';
$telefono = $_POST['telefono'] ?? '';
$password = $_POST['password'] ?? '';
$confirmar = $_POST['confirmar'] ?? '';

// Validar contraseñas
if ($password !== $confirmar) {
    die("Error: Las contraseñas no coinciden");
}

// Encripta
$hash = password_hash($password, PASSWORD_DEFAULT);

// Inserta en la base
$sql = "INSERT INTO arrendadores (nombre, email, fecha_nacimiento, telefono, password)
        VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssss", $nombre, $email, $fecha_nacimiento, $telefono, $hash);
if ($stmt->execute()) {
    echo "Registro exitoso";
} else {
    echo "Error: " . $conn->error;
}
$stmt->close();
$conn->close();
?>
